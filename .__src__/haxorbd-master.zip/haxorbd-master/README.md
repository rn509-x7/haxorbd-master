<p align="left">
<a href="#"><img title="Made in Bangladesh" src="https://img.shields.io/badge/MADE%20IN-BANGLADESH-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="Haxor BD" src=".__src__/haxorbd.png"></a>
<p align="center">
<a href="https://github.com/htr-tech"><img title="Author" src="https://img.shields.io/badge/Author-htr--tech-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/htr-tech/followers"><img title="Followers" src="https://img.shields.io/github/followers/htr-tech?color=blue&style=flat-square"></a>
<a href="https://github.com/htr-tech/haxorbd/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/htr-tech/haxorbd?color=red&style=flat-square"></a>
<a href="https://github.com/htr-tech/haxorbd/network/members"><img title="Forks" src="https://img.shields.io/github/forks/htr-tech/haxorbd?color=red&style=flat-square"></a>
<a href="https://github.com/htr-tech/haxorbd/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/htr-tech/haxorbd?label=Watchers&color=blue&style=flat-square"></a>
</p>

## Installation :

* `apt update`
* `apt install git python python2 -y`
* `git clone https://github.com/htr-tech/haxorbd.git`
* `cd haxorbd`

#### > Run : `python2 haxor.py`

#### USERNAME : `haxor`
#### PASSWORD : `htrtech`

## Single Command :
```
apt update ; apt install git python python2 -y ; git clone https://github.com/htr-tech/haxorbd.git ; cd haxorbd ; python2 haxor.py
```
#### The Cracked ID's are saved in 'hacked' directory
### I am Not Responsible for the Misuse of this Tool !!
<br>
<p align="center">
<img src=".__src__/haxorbd1.png"/>
</p>

### << I AM NOT RESPONSIBLE FOR MISUSE >>
### <<< If you copy , Then Give me The Credits >>> 

## Features :
#### [+] No Login Required !
#### [+] All Bangladeshi Operators are Available !
#### [+] 7,8,9,10,11 DIGITS are Available !
#### [+] Easy for Beginners !

## Find Me on :
[![Github](https://img.shields.io/badge/Github-HTR--TECH-green?style=for-the-badge&logo=github)](https://github.com/htr-tech)
[![Gitlab](https://img.shields.io/badge/Gitlab-HTR--TECH-green?style=for-the-badge&logo=gitlab)](https://gitlab.com/htr-tech)
[![Instagram](https://img.shields.io/badge/IG-%40tahmid.rayat-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/tahmid.rayat)
[![Facebook](https://img.shields.io/badge/Facebook-green?style=for-the-badge&logo=facebook)](https://fb.com/tahmid.rayat.official)
[![Messenger](https://img.shields.io/badge/Chat-Messenger-blue?style=for-the-badge&logo=messenger)](https://m.me/tahmid.rayat.official)
